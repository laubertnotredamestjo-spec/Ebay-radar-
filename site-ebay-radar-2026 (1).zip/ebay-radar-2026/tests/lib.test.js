const test = require('node:test');
const assert = require('node:assert/strict');
const { median, cleanQuery, simplifyItem, computeProfit } = require('../lib');
test('mediane sur nombres de prix', () => {
  assert.equal(median([8, 2, 5]), 5);
  assert.equal(median([8, 2, 5, 3]), 4);
  assert.equal(median([]), null);
});
test('recherche validee et reduite', () => {
  assert.equal(cleanQuery('  Nintendo    DS   '), 'Nintendo DS');
  assert.equal(cleanQuery('a'.repeat(200)).length, 100);
});
test('annonce invalide ecartee', () => {
  assert.equal(simplifyItem({ price: { value: 'NaN' } }), null);
  assert.equal(simplifyItem({ price: { value: '4', currency: 'EUR' }, title: 'Test' }).price, 4);
});
test('marge calculee avec commission et couts', () => {
  const r = computeProfit({ purchase: 20, sale: 50, postage: 5, feeRate: 10, fixedFee: 0.5, other: 2 });
  assert.equal(r.profit, 17.5);
  assert.equal(r.fees, 5.5);
  assert.equal(computeProfit({ purchase: -1 }), null);
});
