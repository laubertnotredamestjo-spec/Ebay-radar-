'use strict';
const $ = id => document.getElementById(id);
const demoItems = [
  {id:'demo-ds',title:'Nintendo DS Lite · console portable (exemple)',price:32,currency:'EUR',shipping:4.5,condition:'Occasion',emoji:'🎮',category:'console',keywords:'nintendo ds lite console retro game boy jeux video',demo:true},
  {id:'demo-gba',title:'Game Boy Advance SP · console rétro (exemple)',price:69,currency:'EUR',shipping:5,condition:'Occasion',emoji:'🕹️',category:'console',keywords:'nintendo game boy advance sp console retro jeux video',demo:true},
  {id:'demo-ixus',title:'Canon IXUS · appareil photo numérique compact (exemple)',price:56,currency:'EUR',shipping:6,condition:'Occasion',emoji:'📸',category:'photo',keywords:'appareil photo compact numerique canon ixus vintage',demo:true},
  {id:'demo-lego',title:'LEGO Star Wars · set d’occasion complet (exemple)',price:48,currency:'EUR',shipping:6,condition:'Occasion',emoji:'🧱',category:'lego',keywords:'lego star wars technic occasion set complet',demo:true},
  {id:'demo-ipod',title:'Apple iPod Classic · baladeur musical (exemple)',price:79,currency:'EUR',shipping:5,condition:'Occasion',emoji:'🎧',category:'audio',keywords:'apple ipod classic baladeur audio musique',demo:true},
  {id:'demo-pokemon',title:'Carte Pokémon · collection (exemple)',price:19,currency:'EUR',shipping:2.5,condition:'Occasion',emoji:'🃏',category:'collection',keywords:'carte pokemon collection vintage',demo:true},
  {id:'demo-objectif',title:'Objectif Canon EF · photographie (exemple)',price:85,currency:'EUR',shipping:6,condition:'Occasion',emoji:'🔭',category:'photo',keywords:'objectif photo canon ef optique',demo:true},
  {id:'demo-veste',title:'Veste vintage de marque · seconde main (exemple)',price:43,currency:'EUR',shipping:5,condition:'Occasion',emoji:'🧥',category:'mode',keywords:'veste vintage marque mode seconde main',demo:true}
];
const suggestions = demoItems;
const state = {configured:false,loginConfigured:false,connected:false,username:null,view:'explore',query:'',live:false,items:[...demoItems],total:null,updatedAt:null,sort:'relevance',favorites:loadFavorites(),busy:false};
const euro = value => Number(value).toLocaleString('fr-FR',{style:'currency',currency:'EUR',minimumFractionDigits:2,maximumFractionDigits:2});
const number = value => Number(value).toLocaleString('fr-FR');
const normalize = s => String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
const n = id => Math.max(0,Number($(id).value || 0));
function loadFavorites(){try{const x=JSON.parse(localStorage.getItem('ebradar:favs')||'[]');return Array.isArray(x)?x.slice(0,100):[]}catch{return []}}
function saveFavorites(){try{localStorage.setItem('ebradar:favs',JSON.stringify(state.favorites))}catch{notify('Navigateur : stockage des favoris indisponible.')}}
function el(tag,cls,text){const e=document.createElement(tag);if(cls)e.className=cls;if(text!==undefined)e.textContent=text;return e}
let toastTimer;function notify(msg){const box=$('toast');box.textContent=msg;box.hidden=false;clearTimeout(toastTimer);toastTimer=setTimeout(()=>box.hidden=true,5200)}
function readNotice(){const val=new URLSearchParams(location.search).get('notice');if(!val)return;const messages={config:'La connexion requiert les clés développeur eBay et le RuName. Consulte le README du projet.',oauth:'Connexion eBay non terminée : vérifie les autorisations et la configuration.',connected:'Compte eBay connecté avec succès.'};if(messages[val])setTimeout(()=>notify(messages[val]),300);if(location.protocol.startsWith('http'))history.replaceState(null,'',location.pathname)}
async function initStatus(){
  try{const res=await fetch('/api/status',{cache:'no-store'});if(!res.ok)throw Error('no status');Object.assign(state,await res.json());}catch{state.configured=false;state.loginConfigured=false;state.connected=false;}
  const pill=$('modePill');pill.classList.toggle('live',state.configured);pill.innerHTML='';const dot=el('i');pill.append(dot,document.createTextNode(state.configured?' API eBay configurée':' Mode démonstration'));
  const strip=$('disclaimer');if(state.configured){strip.classList.add('live-info');strip.replaceChildren(el('span','', 'ⓘ'),el('div','', 'Les annonces en direct indiquent des prix demandés et le nombre d’offres actives. Elles ne prouvent ni le volume de recherches en 2026, ni les ventes réalisées.'))}
  $('connectText').textContent=state.connected?`✓ ${String(state.username||'Compte connecté').slice(0,25)}`:'Connecter eBay';
  $('connectBtn').title=state.connected?'Cliquer pour déconnecter ton compte':'Se connecter à eBay de manière sécurisée';
  readNotice();
  render();
}
function selectView(view){
  state.view=view;
  for(const v of ['explore','saved','guide'])$(v+'View').hidden=v!==view;
  document.querySelectorAll('.nav-item').forEach(b=>b.classList.toggle('active',b.dataset.view===view));
  $('viewName').textContent=({explore:'Explorer',saved:'Mes favoris',guide:'Comprendre les données'})[view];
  if(view==='saved')renderSaved();
  window.scrollTo({top:0,behavior:'smooth'});
}
function filteredDemo(query){
  const words=normalize(query).split(/\s+/).filter(Boolean);
  if(!words.length)return [...demoItems];
  return demoItems.filter(i=>words.some(w=>normalize(i.keywords+' '+i.title).includes(w)));
}
function showLoading(){
  const container=$('productList');container.replaceChildren();const loader=el('div','loading');loader.append(el('div','spinner'),el('div','','Recherche des annonces eBay…'));container.append(loader);
}
async function doSearch(query){
  query=String(query||'').trim().slice(0,100);
  if(!query){notify('Indique un produit ou un modèle précis.');return}
  state.query=query;$('searchInput').value=query;selectView('explore');
  if(!state.configured){state.live=false;state.items=filteredDemo(query);state.total=null;state.updatedAt=null;render();if(!state.items.length)notify('Aucun exemple correspondant. Configure l’API eBay pour chercher ce produit en direct.');return;}
  state.busy=true;showLoading();$('resultsTitle').textContent=`Recherche : ${query}`;$('resultsSubtitle').textContent='Chargement des annonces actives…';
  try{
    const r=await fetch('/api/search?q='+encodeURIComponent(query),{cache:'no-store'});
    const data=await r.json();if(!r.ok)throw Error(data.error||'Recherche impossible');
    state.live=true;state.items=Array.isArray(data.items)?data.items:[];state.total=data.total;state.updatedAt=data.updatedAt;
  }catch(e){state.live=false;state.items=[];state.total=null;state.updatedAt=null;notify(e.message||'Impossible de contacter eBay.');}
  state.busy=false;render();
}
function priceStats(items){const prices=items.map(x=>Number(x.price)).filter(Number.isFinite).sort((a,b)=>a-b);if(!prices.length)return {median:null,min:null};const m=Math.floor(prices.length/2);return {median:prices.length%2?prices[m]:(prices[m-1]+prices[m])/2,min:prices[0]}}
function updateMetrics(){
  const ps=priceStats(state.items);
  $('metricTotal').textContent=state.live?(state.total==null?'—':number(state.total)):'—';
  $('metricMedian').textContent=ps.median!==null?euro(ps.median):'—';
  $('metricLow').textContent=ps.min!==null?euro(ps.min):'—';
  $('metricFav').textContent=String(state.favorites.length);
  $('favCount').textContent=String(state.favorites.length);
  $('updatedBadge').textContent=state.live?(state.updatedAt?'Annonces actives · actualisé':'Annonces eBay'):'Prix fictifs · démo';
}
function itemLink(item){if(item.demo)return 'https://www.ebay.fr/sch/i.html?_nkw='+encodeURIComponent(item.title.replace(/\(exemple\)/g,'').replace('·',' '));try{const u=new URL(item.url);return u.protocol==='https:'&&(/(^|\.)ebay\.(fr|com|de|co\.uk)$/.test(u.hostname))?u.href:'https://www.ebay.fr/';}catch{return 'https://www.ebay.fr/'}}
function goodImageUrl(url){try{const u=new URL(url);return u.protocol==='https:'&&/(^|\.)ebayimg\.com$/.test(u.hostname);}catch{return false}}
function productCard(item,stats){
  const card=el('article','product-card');
  const thumb=el('div','product-thumb');if(item.image&&goodImageUrl(item.image)){const img=el('img');img.src=item.image;img.alt='Photo du produit';img.loading='lazy';thumb.append(img)}else thumb.textContent=item.emoji||'📦';
  const details=el('div','product-details');const tag=el('span','product-tag',item.demo?'EXEMPLE FICTIF':(stats.median&&item.price<stats.median*.8?'Sous la médiane*':'ANNONCE ACTIVE'));
  const title=el('h4','',item.title);const meta=el('div','product-meta');meta.append(el('span','',item.condition||'État non précisé'),el('span','','·'),el('span','',item.shipping===null||item.shipping===undefined?'Livraison à vérifier':`Livraison affichée : ${euro(item.shipping)}`));
  details.append(tag,title,meta);
  const right=el('div','product-right');const priceBlock=el('div');priceBlock.append(el('div','product-price',euro(item.price)),el('div','small-muted',item.demo?'prix fictif':'prix demandé'));
  const actions=el('div','product-actions');
  const choose=el('button','estimate-btn','Calculer');choose.type='button';choose.title='Utiliser ce prix dans le calculateur';choose.addEventListener('click',()=>{$('salePrice').value=Number(item.price).toFixed(2);recalc();$('calcTitle').scrollIntoView({behavior:'smooth',block:'center'});notify('Prix de revente inséré : complète tes coûts réels.')});
  const saved=state.favorites.some(x=>x.id===item.id);const save=el('button','save-btn'+(saved?' saved':''),saved?'★':'☆');save.type='button';save.title=saved?'Retirer des favoris':'Ajouter aux favoris';save.setAttribute('aria-label',save.title);save.addEventListener('click',()=>toggleFavorite(item));
  const open=el('a','open-btn','↗');open.href=itemLink(item);open.target='_blank';open.rel='noopener noreferrer';open.title=item.demo?'Rechercher ce produit sur eBay':'Voir l’annonce sur eBay';open.setAttribute('aria-label',open.title);
  actions.append(choose,save,open);right.append(priceBlock,actions);card.append(thumb,details,right);return card;
}
function renderProducts(){
  const list=$('productList');list.replaceChildren();
  const sorted=[...state.items];if(state.sort==='low')sorted.sort((a,b)=>a.price-b.price);if(state.sort==='high')sorted.sort((a,b)=>b.price-a.price);
  const stats=priceStats(state.items);
  if(!sorted.length){const empty=el('div','empty');empty.append(el('span','','⌕'),el('strong','',state.configured?'Aucune annonce trouvée':'Aucun exemple trouvé'),el('p','',state.configured?'Essaie des mots-clés plus précis ou un autre modèle.':'Le mode démonstration ne contient que quelques exemples. Configure l’API eBay pour explorer ce produit.'));list.append(empty)}
  for(const item of sorted)list.append(productCard(item,stats));
  $('resultsTitle').textContent=state.query?`Résultats : ${state.query}`:'Sélection de produits';
  $('resultsSubtitle').textContent=state.live?`${state.items.length} annonces eBay affichées · France`:'Exemples fictifs — pas un classement des tendances 2026';
  $('resultsFooter').textContent=state.live?'*Un prix sous la médiane peut concerner un état, un modèle ou un accessoire différent. Ces annonces ne sont pas des ventes conclues.':'Exemples illustratifs. Aucune popularité, vente ni marge réelle n’a été observée.';
}
function toggleFavorite(item){
  const idx=state.favorites.findIndex(x=>x.id===item.id);
  if(idx>=0)state.favorites.splice(idx,1);else state.favorites.unshift(item);
  state.favorites=state.favorites.slice(0,100);saveFavorites();render();
  if(state.view==='saved')renderSaved();
  notify(idx>=0?'Retiré des favoris.':'Produit ajouté à tes favoris.');
}
function renderSaved(){const list=$('savedList');list.replaceChildren();if(!state.favorites.length){const empty=el('div','empty');empty.append(el('span','','☆'),el('strong','','Aucun favori pour le moment'),el('p','','Clique sur l’étoile d’un produit pour le garder dans cette liste.'));list.append(empty);return}const stats=priceStats(state.favorites);for(const x of state.favorites)list.append(productCard(x,stats));}
function render(){updateMetrics();renderProducts();if(state.view==='saved')renderSaved()}
function recalc(){
  const sale=n('salePrice'),purchase=n('purchasePrice'),shipping=n('shippingCost'),rate=n('feeRate'),fixed=n('fixedFee'),other=n('otherCost');
  const fees=sale*rate/100+fixed,profit=sale-purchase-shipping-fees-other,margin=sale>0?(profit/sale*100):null;
  $('profitDisplay').textContent=(profit>0?'+':'')+euro(profit);$('profitDisplay').classList.toggle('negative',profit<0);
  $('feeDisplay').textContent=euro(fees);$('marginDisplay').textContent=margin===null?'—':margin.toLocaleString('fr-FR',{maximumFractionDigits:1})+' %';
}
function exportCSV(){
  if(!state.favorites.length){notify('Tu n’as encore enregistré aucun produit.');return}
  const rows=[['Nom','Prix annonce (EUR)','Livraison affichée (EUR)','État','Mode','Lien eBay']];
  state.favorites.forEach(x=>rows.push([x.title,x.price,x.shipping??'',x.condition||'',x.demo?'Exemple fictif':'Annonce active',itemLink(x)]));
  const csv='\ufeff'+rows.map(r=>r.map(x=>'"'+String(x).replace(/"/g,'""')+'"').join(';')).join('\r\n');
  const blob=new Blob([csv],{type:'text/csv;charset=utf-8'});const href=URL.createObjectURL(blob);const a=el('a');a.href=href;a.download='ebay-radar-favoris.csv';document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(href),2000);
}
async function handleConnection(){
  if(!state.loginConfigured){notify('Pour connecter eBay, installe le projet et renseigne EBAY_CLIENT_ID, EBAY_CLIENT_SECRET et EBAY_RUNAME dans .env.');return}
  if(state.connected){if(!confirm('Déconnecter le compte eBay de ce tableau de bord ?'))return;try{await fetch('/api/disconnect',{method:'POST'});state.connected=false;state.username=null;$('connectText').textContent='Connecter eBay';notify('Compte déconnecté du site. Tu peux aussi révoquer l’autorisation côté eBay.')}catch{notify('Impossible de se déconnecter actuellement.')}return}
  location.assign('/auth/ebay');
}
function setupEvents(){
  document.querySelectorAll('[data-view]').forEach(btn=>btn.addEventListener('click',()=>selectView(btn.dataset.view)));
  document.querySelectorAll('[data-query]').forEach(btn=>btn.addEventListener('click',()=>doSearch(btn.dataset.query)));
  $('heroExploreBtn').addEventListener('click',()=>$('searchInput').scrollIntoView({behavior:'smooth',block:'center'}));
  $('searchForm').addEventListener('submit',e=>{e.preventDefault();doSearch($('searchInput').value)});
  $('sortSelect').addEventListener('change',e=>{state.sort=e.target.value;renderProducts()});
  $('calcForm').querySelectorAll('input').forEach(input=>input.addEventListener('input',recalc));
  $('exportBtn').addEventListener('click',exportCSV);
  $('connectBtn').addEventListener('click',handleConnection);
}
setupEvents();recalc();render();initStatus();
